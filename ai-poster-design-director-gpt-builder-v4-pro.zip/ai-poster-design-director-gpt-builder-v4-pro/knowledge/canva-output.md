# Canva Output Standard

## 1. Canvas

State:
- format name
- pixel or physical dimensions
- orientation
- bleed and safe-zone notes

Common digital sizes:
- Instagram portrait: 1080 x 1350 px
- Instagram square: 1080 x 1080 px
- Story / Reel cover: 1080 x 1920 px
- Presentation / LED: 1920 x 1080 px

For print, confirm printer requirements.

## 2. Zone wireframe

Describe zones from top to bottom and left to right:
- logo or eyebrow zone
- headline zone
- hero visual zone
- event detail zone
- CTA and QR zone
- organizer and sponsor footer

Include approximate percentage height or relative size.

## 3. Palette

Provide:
- Primary 60%: HEX and uses
- Secondary 30%: HEX and uses
- Accent 10%: HEX and uses
- optional neutral text/background colors

## 4. Typography

Provide Canva-available fonts or close substitutes:
- headline
- supporting headline
- body
- numeric/date accent

State relative scale, weights, capitalization, tracking, and alignment.

## 5. Canva search keywords

Organize into:
- photos
- graphics
- frames
- textures
- icons
- decorative elements
- background effects

Use search-friendly English phrases.

## 6. Layer order

List back to front:
1. background color or image
2. texture or gradient overlay
3. decorative shapes
4. hero image
5. image mask or shadow
6. information panel
7. title and subtitle
8. date/time/venue
9. CTA and QR
10. logos and sponsor footer

## 7. Construction instructions

State:
- crop and positioning
- transparency percentages when useful
- background remover or blur use
- corner radius
- border thickness
- shadow direction and softness
- grouping and locking
- alignment guides
- margins, padding, and gaps

## 8. Export

- Social: PNG, RGB, correct dimensions.
- Lightweight preview: JPG at high quality.
- Print: PDF Print, bleed and crop marks only when required.
- Transparent asset: PNG with transparent background when supported.

## 9. Complexity level

- **Level 1**: basic Canva tools, 5-15 minutes, simple photo + typography.
- **Level 2**: layered shapes, masks, gradients, and moderate image treatment, 15-40 minutes.
- **Level 3**: custom AI hero image, complex compositing, manual retouching, or external vector work, 40+ minutes.

## 10. Feasibility note

Clearly identify:
- fully achievable in Canva
- achievable with Canva Pro features
- requires generated or externally prepared assets
- better handled in Photoshop, Illustrator, Figma, or another tool
