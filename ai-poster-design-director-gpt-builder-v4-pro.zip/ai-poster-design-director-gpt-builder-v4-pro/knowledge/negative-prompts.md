# Negative Prompt System

Select only categories relevant to the requested visual.

## General quality

low resolution, blurry, pixelated, compression artifacts, unintended noise, muddy details, poor focus, accidental crop, duplicate objects, watermark, signature, unwanted logo

## Layout and poster design

cluttered layout, weak hierarchy, random placement, misalignment, inconsistent margins, uneven spacing, overlapping elements, tiny unreadable text, cropped text, crowded footer, excessive decoration, multiple competing focal points

## Typography

gibberish text, misspelled words, random letters, duplicated text, broken glyphs, illegible typography, mixed font styles, warped text, meaningless symbols, unwanted text

## Human anatomy

extra fingers, missing fingers, fused fingers, malformed hands, extra limbs, duplicate person, distorted face, crossed eyes, unnatural pose, inconsistent body proportions

## Photography

camera shake, accidental motion blur, harsh blown highlights, crushed shadows, flat lighting, unwanted fisheye distortion, unnatural skin texture, excessive sharpening, plastic skin

## 3D and rendering

broken geometry, floating objects, melted surfaces, incorrect reflections, inconsistent shadows, low-poly artifacts, texture stretching, unrealistic material response

## Corporate and premium

cheap clipart, childish icons, generic stock-template appearance, rainbow palette, excessive gradients, overdecorated background, amateur composition, flashy effects, unrelated luxury props

## Brand and logos

fake logos, distorted logos, oversized sponsor marks, inconsistent brand colors, unauthorized trademarks, logo dominating the composition

## Event safety and relevance

irrelevant weapons, graphic violence, gore, sexualized pose, offensive symbols, political propaganda, religious symbolism unless required, unrelated background elements

## Platform handling

- ChatGPT Images: convert exclusions into direct sentences.
- Midjourney: use a short `--no` list.
- SDXL: use a comma-separated negative prompt.
- Flux: keep exclusions minimal and specific.
- Ideogram: prioritize no misspelling, no extra text, no warped letters, and no duplicated copy.
