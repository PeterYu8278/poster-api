# v4 Pro setup

## GPT Builder
1. Create or edit the GPT.
2. Paste `GPT_INSTRUCTIONS.md` into Instructions.
3. Upload every file in `knowledge/`.
4. Add an Action using `actions/poster-api-openapi.yaml` after replacing `YOUR_API_BASE_URL`.
5. Configure Action authentication with your gateway key, not provider keys.
6. Add a valid privacy-policy URL if publishing publicly.

## Gateway
Follow `gateway/README.md`. Set Pexels, Unsplash, Pixabay and Google Fonts keys in `.env`. Providers without keys are skipped with warnings.

## Tests
- `GET /v1/health`
- Search photos with `query=business networking ballroom&orientation=portrait&limit=8`
- Search Pexels video.
- Choose an Unsplash result and call select using its exact `download_location`.
- Verify 401 without gateway auth and failover when one provider key is absent.
