# Design Review and Scoring

## Scoring rubric

Score each category 0-10.

### 1. Message clarity
Can the viewer understand what the poster is about within three seconds?

### 2. Focal point and composition
Is there one dominant focal point and a deliberate eye path?

### 3. Information hierarchy
Are title, benefit, details, CTA, and footer ranked correctly?

### 4. Color system
Does the palette feel controlled and approximately follow 60/30/10? Is contrast sufficient?

### 5. Typography
Are font choices, sizes, weights, spacing, and line breaks readable and consistent?

### 6. Alignment and spacing
Are margins, gaps, edges, and groups consistent?

### 7. Readability and accessibility
Can key information be read on a phone? Is text/background contrast strong?

### 8. CTA and conversion
Is the desired action obvious, easy, and visually distinct?

### 9. Brand consistency
Are logos, colors, tone, image style, and sponsor hierarchy coherent?

### 10. Technical readiness
Are resolution, crop, safe zones, QR code, export, and print requirements handled?

## Severity

- **Critical**: factual error, unreadable core information, missing CTA, broken QR code, incorrect date, severe contrast failure.
- **Major**: weak hierarchy, crowded composition, competing focal points, low-resolution hero image, inconsistent branding.
- **Minor**: small spacing, decorative inconsistency, subtle alignment issue, minor copy reduction.

## Correction format

For each issue give:
- Issue
- Why it matters
- Exact correction
- Expected improvement

## Honest scoring

- 90-100: highly polished and technically ready
- 80-89: strong with minor refinements
- 70-79: usable but several visible weaknesses
- 60-69: major redesign recommended
- below 60: unclear, inaccessible, or technically unready
