# Poster Design System

## 1. One-message discipline

A poster should communicate one primary message and one primary action. Secondary content must support, not compete with, the core message.

## 2. Color: 60 / 30 / 10

- **60% primary**: background, dominant field, large shapes, overall atmosphere.
- **30% secondary**: cards, panels, supporting illustrations, section separation.
- **10% accent**: CTA, date highlight, price, limited-seat notice, key number.

Use one accent color by default. A second accent is acceptable only for a persistent semantic distinction. Verify contrast rather than relying on hue alone.

## 3. Reading order

Default eye flow:
- left to right
- top to bottom
- large to small

For Chinese-English bilingual posters, keep each language block internally consistent. Avoid forcing the viewer to jump repeatedly across the canvas.

## 4. Hierarchy

Use clear size and weight differences:
- title: dominant
- benefit or theme: strong secondary
- date/time/venue: quickly scannable
- CTA: visually distinct
- body/supporting copy: restrained
- organizer and sponsor area: smallest functional tier

Avoid making more than three elements compete at the highest visual level.

## 5. Layout patterns

- **Z pattern**: strong for event posters and simple landing graphics.
- **F pattern**: useful for information-heavy schedules or educational posters.
- **Centered hero**: useful for guest announcements, product features, or ceremonial events.
- **Split layout**: useful for image + details or two-part programs.
- **Modular grid**: useful for agendas, benefits, speakers, or multi-card information.
- **Editorial asymmetry**: useful for premium cultural, fashion, or creative events.

## 6. Grid and spacing

- Use a consistent grid, commonly 4, 6, or 12 columns.
- Use an 8-point spacing rhythm when possible.
- Keep outer margins larger than internal gaps.
- Align unrelated elements only when the alignment supports eye flow.
- Preserve 20-30% visual breathing room in modern poster designs unless a deliberate dense style is required.

## 7. Typography

- Use at most two font families by default.
- Pair a display or bold heading face with a highly readable body face.
- Avoid long all-caps paragraphs.
- Keep line lengths short on portrait social posters.
- Use weight, size, and spacing before introducing more colors.
- Confirm Canva font availability before recommending exact Canva fonts.

## 8. Images and focal point

- Use one dominant hero subject.
- Avoid multiple equal-size faces unless the event is explicitly a panel or lineup.
- Keep important faces, hands, products, and logos away from crop zones.
- Reserve clean text-safe negative space.
- Do not place body text over visually complex areas without a supporting overlay.

## 9. CTA and QR code

- Use the accent color for the main CTA.
- Use direct wording: Register Now, Scan to Join, Book Your Seat, Learn More.
- Keep the QR code on a clean high-contrast background.
- Do not stylize the QR code aggressively.
- Leave clear space around it and include a short instruction.

## 10. Logo hierarchy

Default order:
1. event identity or organizer
2. strategic partners
3. sponsors
4. supporting organizations

Keep logo heights consistent within each tier. Never stretch logos. Avoid white boxes around some logos unless all logos are treated consistently.

## 11. Mobile readability

At thumbnail size, viewers should still recognize:
- event title
- date
- key visual
- CTA

Reduce copy rather than shrinking it excessively.

## 12. Accessibility

- Use strong text/background contrast.
- Do not rely on color alone to convey meaning.
- Avoid thin text on detailed photographs.
- Use readable type sizes and sufficient line spacing.
- Check common red-green confusion risks for status or category encoding.

## 13. Print readiness

- Use 300 dpi equivalent assets for print.
- Add bleed when required by the printer, commonly 3 mm.
- Keep critical text and logos inside the safe zone.
- Use PDF Print and appropriate color handling.
- Confirm final trim size with the printer; do not assume all A4 or banner production settings are identical.
