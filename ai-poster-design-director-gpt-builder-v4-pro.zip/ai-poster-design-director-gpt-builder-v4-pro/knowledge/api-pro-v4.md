# API Pro v4 workflow

## Environment
- `POSTER_API_BASE_URL=https://YOUR_API_BASE_URL`
- `POSTER_API_KEY=YOUR_GATEWAY_API_KEY`
- `POSTER_API_AUTH_HEADER=Authorization`
- `POSTER_API_AUTH_SCHEME=Bearer`

Never store provider keys in the Skill or GPT instructions. Provider keys belong only in the gateway environment.

## Unified endpoints
- `GET /v1/assets/photos/search`
- `GET /v1/assets/videos/search`
- `GET /v1/assets/icons/search`
- `GET /v1/assets/fonts/search`
- `POST /v1/assets/photos/{provider}/{id}/select`
- `POST /v1/images/generate` (consequential/possibly paid)
- `GET /v1/health`

## Failover
Try requested providers in configured order. On 429 or transient 5xx, continue to the next provider. Do not silently hide authentication failures.

## Security
Use HTTPS, restrict outbound hosts, cap query lengths and result counts, validate Unsplash download hosts, set timeouts, redact secrets, and rate-limit the gateway.
