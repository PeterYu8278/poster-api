# Uploaded Image Analysis Schema

## Accuracy rules

- Analyze only what is visible.
- Use "appears", "likely", or "estimated" when exact identification is uncertain.
- Do not identify a person unless the user asks and identification is appropriate.
- Do not claim an exact font, lens, renderer, or HEX value from appearance alone. Provide close matches or estimates.
- Separate observation from interpretation.

## A. Subject

Describe:
- primary subject and secondary subjects
- approximate age group when relevant, without overclaiming
- visible physical characteristics
- outfit, material, accessories, props
- facial expression and gaze
- pose, gesture, movement, action
- subject placement and relative canvas size
- foreground/background separation

## B. Environment and background

Describe:
- interior, exterior, studio, abstract, fantasy, or hybrid setting
- architecture, furniture, landscape, signage, props
- foreground, midground, background layers
- depth, atmosphere, haze, particles, texture
- background complexity and available negative space

## C. Composition and viewpoint

Describe:
- close-up, medium, full-body, wide, macro, aerial, low-angle, eye-level
- focal length feel: wide, normal, telephoto-like
- crop and framing
- symmetry, asymmetry, rule of thirds, centered composition
- leading lines, diagonals, frames within frames
- balance, visual weight, and eye flow
- likely title-safe and detail-safe areas

## D. Lighting and color

Describe:
- apparent key light direction
- fill, rim, backlight, practical lights
- hard or soft light
- high-key, low-key, high-contrast, flat, cinematic
- warm, neutral, or cool temperature
- shadow depth and highlight behavior
- dominant, secondary, and accent colors
- approximate HEX palette when useful
- estimated 60/30/10 allocation
- color relationship: complementary, analogous, monochromatic, split-complementary, neutral plus accent

## E. Style and medium

Classify visual language:
- documentary or commercial photography
- editorial portrait
- vector illustration
- flat or geometric design
- watercolor, ink, collage, paper cut
- 3D render, clay, glass, metallic, product visualization
- cel animation, anime-inspired, comic, retro print
- Swiss, Bauhaus, Muji-inspired minimalism, luxury editorial, corporate, futuristic, cyberpunk, Y2K, brutalist, bento, glassmorphism

When a reference resembles a protected creator's signature style, translate it into general features such as palette, line quality, composition, texture, era, and medium.

## F. Quality and modifiers

Describe only useful attributes:
- sharp focus or intentionally soft focus
- depth of field and bokeh
- texture, grain, noise, bloom
- crisp vector edges or painterly detail
- realistic materials and reflections
- high-detail, print-ready, polished editorial finish
- renderer vocabulary only as an optional recreation suggestion, not a claim

Avoid empty keyword inflation such as stacking masterpiece, 16K, 32K, ultra-HD, award-winning, best quality without explaining what quality means.

## Design DNA output

Return:
1. one-sentence identity
2. five defining principles
3. palette with roles
4. typography characteristics
5. composition formula
6. lighting formula
7. texture and material language
8. 10-20 reusable keywords
9. elements to avoid copying directly
10. original recreation prompt
