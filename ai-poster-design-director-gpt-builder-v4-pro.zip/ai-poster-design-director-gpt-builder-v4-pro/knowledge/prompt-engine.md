# Prompt Engine

## Core prompt formula

Build prompts in this order:

1. purpose and output format
2. subject
3. environment and background
4. composition and camera viewpoint
5. lighting and color
6. style and medium
7. material, texture, and detail
8. text-safe negative space and layout needs
9. quality and production constraints
10. exclusions

## Prompt quality rules

- Use concrete visual descriptions.
- Avoid conflicting styles or lighting instructions.
- State the intended aspect ratio and crop.
- Reserve clean space for final typography.
- Do not ask an image model to render large amounts of event copy.
- Generate a background or hero visual first, then place verified text in Canva.
- Keep names and branded content out of image-generation prompts unless authorized and necessary.

## ChatGPT Images

Use natural language. Include:
- exact subject and action
- clean poster composition
- explicit negative space
- desired palette and lighting
- instruction to avoid watermark, logos, gibberish, and unwanted text
- final crop and orientation

## Midjourney

Provide:
- compact descriptive prompt
- aspect ratio, for example `--ar 4:5`
- restrained stylization when layout control matters
- focused `--no` terms

Do not assume a specific model version unless the user requests it.

## Flux

Use coherent sentences and specific visual relationships. Keep negative wording short. Emphasize placement, materials, lighting, and text-safe space.

## SDXL / Stable Diffusion

Provide:
- positive prompt
- negative prompt
- aspect ratio or dimensions
- optional recommended steps, CFG, and sampler only as starting points

Settings vary across checkpoints and interfaces. Label settings as suggestions.

## Ideogram

When text must appear:
- keep wording short
- put exact text in quotation marks
- specify line breaks and hierarchy
- request clean typography and high contrast
- warn the user to proofread every word

## Firefly, Leonardo, Recraft

- Firefly: emphasize commercial-safe, editable, photographic, illustration, or text-effect intent.
- Leonardo: provide prompt plus image guidance and composition notes.
- Recraft: specify vector, icon, illustration, or brand-system output when editable graphics are needed.
