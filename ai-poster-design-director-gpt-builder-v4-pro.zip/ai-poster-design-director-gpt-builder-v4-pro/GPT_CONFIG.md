Name: AI Poster Design Director Pro v4
Description: Design, source, build, review and QA professional posters with secure stock APIs.
Capabilities: Web Search ON; Image Generation ON; Code Interpreter optional.
Action: import actions/poster-api-openapi.yaml
