# Photo Stock and Design Asset Sourcing

Use this reference when the user asks for suitable stock photos, visual assets, icons, illustrations, fonts, mockups, or source links for a poster.

## Required workflow

1. Translate the design brief into 3-8 concrete English search phrases. Include subject, audience, setting, emotion, composition, lighting, color, and text-safe space when relevant.
2. Select the best source category. Do not search every website by default.
3. When web access is available, search the current website and return actual asset or search-result links, not only the homepage.
4. Verify the current license or usage notice on the asset page before calling an asset commercially usable. License terms can change.
5. Return 3-8 strong candidates, ranked by fit. For each candidate provide source, asset title or description, why it fits, recommended crop/treatment, attribution requirement, and a license-risk note.
6. Prefer assets with clean negative space, sufficient resolution, authentic people, and no visible trademarks or copyrighted characters.
7. Never state that an asset is copyright-free merely because it is free to download.
8. Warn about recognisable people, private property, artworks, trademarks, logos, model/property releases, sensitive uses, and standalone resale.
9. Suggest AI generation only when suitable stock is unavailable, too generic, legally risky, or compositionally unsuitable.
10. Keep an asset record: creator, source URL, asset URL, download date, license URL, and attribution text.

## Source routing

### General photography and video
- Unsplash — https://unsplash.com — premium editorial, lifestyle, architecture, business and atmospheric photography.
- Pexels — https://www.pexels.com — people, events, business, lifestyle, video and social content.
- Pixabay — https://pixabay.com — broad photos, vectors, video, music and effects; check each media type and asset.
- StockSnap — https://stocksnap.io — general photography and alternatives when major libraries are repetitive.
- Burst — https://burst.shopify.com — entrepreneurship, ecommerce, products and small business.
- Life of Pix — https://www.lifeofpix.com — artistic and editorial photography.
- Kaboompics — https://kaboompics.com — lifestyle, interiors, flat lays, workspace and coordinated photo sets.
- Picjumbo — https://picjumbo.com — business, lifestyle, technology and blog imagery.
- ISO Republic — https://isorepublic.com — general photos and video.
- Gratisography — https://gratisography.com — unusual, playful and surreal creative photography.
- Reshot — https://www.reshot.com — distinctive photos, icons and illustrations.
- Foodiesfeed — https://www.foodiesfeed.com — food and beverage.
- SplitShire — https://www.splitshire.com — creative lifestyle and atmospheric photography.
- Freerange Stock — https://freerangestock.com — general photography; account or item conditions may vary.
- Public Domain Pictures — https://www.publicdomainpictures.net — public-domain-oriented collection; verify each asset and jurisdiction.

### Transparent PNG
- PNGWing — https://www.pngwing.com
- CleanPNG — https://www.cleanpng.com
- PNGTree — https://pngtree.com
- StickPNG — https://www.stickpng.com
- KissPNG — https://www.kisspng.com

Treat PNG aggregator sites as higher risk. A transparent background does not prove ownership or commercial permission. Do not recommend branded characters, celebrity cut-outs, logos, product images, or copyrighted artwork from these sites unless rights are independently verified. Prefer official press kits, user-owned assets, open-license vectors, or original AI generation.

### Vector and illustration
- SVG Repo — https://www.svgrepo.com — inspect the license displayed on every asset; licenses vary.
- OpenClipart — https://openclipart.org — simple clipart and public-domain-oriented assets; verify item details.
- unDraw — https://undraw.co — editable modern illustrations; suitable for presentations, corporate and digital materials.
- ManyPixels Gallery — https://www.manypixels.co/gallery — business and product illustrations; verify current terms.
- DrawKit — https://www.drawkit.com — illustration packs; free and paid pack terms differ.

### Icons
- Flaticon — https://www.flaticon.com — broad icon library; free downloads commonly require attribution.
- Icons8 — https://icons8.com — icons and graphics; free use commonly requires attribution/linking and may have format limits.
- Heroicons — https://heroicons.com — clean interface icons, especially digital products.
- Phosphor Icons — https://phosphoricons.com — flexible UI icon family.
- Lucide — https://lucide.dev — open-source interface icons.

Prefer one consistent icon family. Do not mix unrelated stroke weights or corner styles.

### Mockups
- Mockup World — https://www.mockupworld.co
- Unblast — https://unblast.com
- Anthony Boyd Graphics — https://www.anthonyboyd.graphics

Check the original provider's license because mockup directories may link to third-party files.

### Fonts
- Google Fonts — https://fonts.google.com — first choice for accessible, cross-platform and commonly open-licensed fonts.
- DaFont — https://www.dafont.com — license varies by font; many are personal-use-only.
- FontSpace — https://www.fontspace.com — license varies by font and designer.

Never label every font on an aggregator as commercially free. Verify the individual font license and keep the license file.

### AI generation
- Leonardo AI — https://leonardo.ai
- Adobe Firefly — https://firefly.adobe.com
- Ideogram — https://ideogram.ai
- Playground — https://playground.com
- Microsoft Designer — https://designer.microsoft.com
- Freepik AI — https://www.freepik.com

Check current plan limits and output-use terms. Do not promise exclusivity or copyright ownership. Avoid protected characters, logos, public figures, and living artists' signature styles.

## Fast source selection

- Corporate, networking, leadership: Pexels, Unsplash, Burst, Kaboompics.
- Event atmosphere and crowds: Pexels, Unsplash, Pixabay video.
- Food: Foodiesfeed, Pexels, Unsplash.
- Interiors and lifestyle: Kaboompics, Unsplash, Pexels.
- Playful or unconventional campaigns: Gratisography, Reshot.
- Interface icons: Lucide, Heroicons, Phosphor.
- Corporate illustrations: unDraw, ManyPixels, DrawKit.
- Print or device mockups: Mockup World, Unblast, original provider.
- Highly specific hero composition: AI generation or a commissioned shoot.

## Search-query formula

Build queries such as:
`[subject] + [setting] + [emotion/action] + [camera/composition] + [lighting/style] + [negative space]`

Examples:
- `Asian professionals networking ballroom candid wide shot purple lighting copy space`
- `cosplay convention adult attendees socialising premium event vertical portrait`
- `AED training diverse students hands on CPR bright classroom copy space`
- `luxury cigar gift business owner dark editorial close up negative space`

## Output template

### Recommended asset direction
State the best source type and why.

### Search phrases
List precise English phrases ready to paste into the sites.

### Asset shortlist
For each item:
- **Source and asset**
- **Direct link**
- **Fit**
- **Crop/treatment**
- **License/attribution**
- **Risk check**

### Backup plan
Give one alternative source and one AI-generation direction.

### Usage record
Provide a compact checklist for creator, asset URL, license URL, download date and attribution.

## Licensing baseline

Official license summaries indicate that Unsplash, Pexels and Pixabay generally permit broad free use with restrictions such as no unmodified standalone resale, no implied endorsement, and extra caution for trademarks and recognisable people. SVG Repo licenses may differ per asset. Free Flaticon and Icons8 usage commonly requires attribution. Always verify the current official terms and the individual asset page at the time of download.
