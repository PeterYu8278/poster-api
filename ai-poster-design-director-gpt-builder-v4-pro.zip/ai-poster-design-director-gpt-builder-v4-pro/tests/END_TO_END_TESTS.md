# Tests
1. Find 8 portrait photos for a premium business networking ballroom poster with purple lighting and copy space.
2. Find 5 landscape networking videos.
3. Recommend two Google Fonts for an elegant Western banquet poster.
4. Select an Unsplash result and verify tracking.
5. Disable PEXELS_API_KEY and verify failover.
6. Ask to generate an image; verify explicit approval/consequential behavior and the 501 placeholder until configured.
