# API Integration

## Purpose
Use an external API only when the runtime exposes network access and the user has configured credentials. Never claim an API call succeeded unless a tool or script returned a successful response.

## Recommended architecture
Use one user-controlled API gateway instead of embedding many vendor keys in the Skill or GPT:

`Poster Assistant -> YOUR_API_BASE_URL -> Unsplash / Pexels / Pixabay / Iconify / Google Fonts / image services`

The gateway should normalize results and keep provider secrets server-side.

## Placeholders
- `YOUR_API_BASE_URL`: e.g. `https://api.example.com`
- `YOUR_API_KEY`: gateway key; prefer environment variables or GPT Action authentication, never plain text in shared files
- `YOUR_PRIVACY_POLICY_URL`: required for a public GPT using Actions

## Normalized endpoints

### Search photos
`GET /v1/assets/photos/search`

Query:
- `query` required
- `orientation` optional: portrait, landscape, square
- `color` optional
- `page` optional
- `per_page` optional, recommended 3-20
- `providers` optional comma list: unsplash,pexels,pixabay

Expected response:
```json
{
  "results": [
    {
      "id": "provider-id",
      "provider": "pexels",
      "title": "Optional title",
      "creator": "Creator Name",
      "preview_url": "https://...",
      "source_url": "https://...",
      "download_url": "https://...",
      "width": 2400,
      "height": 3000,
      "license_name": "Provider License",
      "license_url": "https://...",
      "attribution_required": false
    }
  ]
}
```

### Search icons or vectors
`GET /v1/assets/icons/search`

Query: `query`, `style`, `limit`, `providers`.
Expected fields: `id`, `provider`, `name`, `preview_url`, `source_url`, `download_url`, `format`, `license_name`, `license_url`, `attribution_required`.

### Search fonts
`GET /v1/assets/fonts/search`

Query: `query`, `category`, `language`, `limit`.
Expected fields: `family`, `category`, `variants`, `source_url`, `license_name`, `license_url`.

### Generate an image
`POST /v1/images/generate`

Body:
```json
{
  "prompt": "...",
  "negative_prompt": "...",
  "aspect_ratio": "4:5",
  "provider": "openai",
  "count": 1
}
```
Return job status and output URLs. Treat generation as consequential: show the prepared prompt and obtain confirmation when the user's instruction does not already clearly authorize generation or cost.

### Check job
`GET /v1/jobs/{job_id}`

## Calling rules
1. Prefer read-only search endpoints automatically when the user asks to find assets.
2. Ask for confirmation before paid generation, uploading, publishing, deleting, or modifying external resources unless the user explicitly requested that action.
3. Send the minimum personal data necessary.
4. Apply timeouts, status checks, pagination, and rate-limit handling.
5. If the API fails, report the status and fall back to web search or manual search phrases.
6. Do not expose keys, bearer tokens, raw authorization headers, or provider secrets in output.
7. Verify item-level licenses; API availability does not guarantee commercial suitability.

## Environment variables for the bundled script
- `POSTER_API_BASE_URL`
- `POSTER_API_KEY`
- Optional `POSTER_API_AUTH_HEADER` defaults to `Authorization`
- Optional `POSTER_API_AUTH_SCHEME` defaults to `Bearer`
