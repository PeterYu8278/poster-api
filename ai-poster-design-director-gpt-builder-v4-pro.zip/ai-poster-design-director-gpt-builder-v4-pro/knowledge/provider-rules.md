# Provider rules

## Unsplash
Header: `Authorization: Client-ID <access key>`. Search `/search/photos`; preserve `urls.*`, `links.html`, creator links, `download_location`, and `ixid`. Trigger `download_location` once the user selects/uses a photo.

## Pexels
Header: `Authorization: <API key>`. Photos `/v1/search`; videos `/videos/search`. Preserve photo/video page and creator links. No Unsplash-style download tracking.

## Pixabay
Query key parameter. Images `/api/`; videos `/api/videos/`. Identify Pixabay as source in displayed results. Avoid systematic mass downloading and permanent hotlink assumptions.

## Google Fonts
Request `/webfonts/v1/webfonts?key=<key>`. Use metadata to recommend families; do not redistribute font files in this Skill.

## Iconify
Use public search endpoints when permitted. Preserve collection/provider and license metadata; item licenses vary by collection.
