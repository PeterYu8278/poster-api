# Output Templates

## A. Complete poster concept

# Recommended Direction

## Design objective
[One sentence]

## Content hierarchy
1. ...

## Visual concept
- Subject:
- Environment:
- Composition:
- Lighting and color:
- Style and medium:
- Quality modifiers:

## Color palette: 60 / 30 / 10
- 60% Primary:
- 30% Secondary:
- 10% Accent:

## Typography
- Heading:
- Body:
- Hierarchy:

## Layout wireframe
[Top-to-bottom zone plan]

## Final copy placement
[Verified copy or placeholders]

## Canva build
[Construction plan]

## AI prompt
[Platform-specific prompt]

## Negative prompt
[Relevant exclusions]

## Design QA
[Score and top fixes]

## B. Uploaded image analysis

# Image Analysis

## Observation summary

## Subject

## Environment and background

## Composition and viewpoint

## Lighting and color

## Style and medium

## Quality and modifiers

## Design DNA

## Reusable visual keywords

## Original recreation prompt

## Canva reconstruction

## C. Poster review

# Poster Review

## What works

## Priority issues
### Critical
### Major
### Minor

## Correction plan

## Revised layout

## Revised Canva instructions

## Improved prompt

## Score: [X]/100
